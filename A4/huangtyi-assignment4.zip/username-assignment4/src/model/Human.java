package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Represents a Human that can move in four directions.
 * This class extends the {@link AbstractVehicle} class and implements
 * specific movement rules for the Human, including the ability to traverse
 * different types of terrain and the conditions under which it can pass
 * through certain terrains.
 *
 * @author TCSS 305 instructors
 * @version 1.0
 */
public class Human extends AbstractVehicle {
    private static final int DEATH_TIME = 40;

    /**
     * Constructs a new Human with the specified initial position and direction.
     *
     * @param x the initial x-coordinate of the Human
     * @param y the initial y-coordinate of the Human
     * @param direction the initial direction the Human is facing
     */
    public Human(int x, int y, Direction direction) {
        super(x, y, direction, DEATH_TIME);
    }

    /**
     * Determines whether this Human can pass over the specified terrain,
     * considering the light color.
     *
     * @param theTerrain the terrain to check
     * @param theLight the color of the street light
     * @return true if the Human can pass; false otherwise
     */
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if (canTravel(theTerrain)) {
            if (theTerrain == Terrain.CROSSWALK && theLight == Light.GREEN) {
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * Chooses the direction this Human would like to move, based on the
     * neighboring terrain provided in a map.
     *
     * @param theNeighbors a map of neighboring terrain
     * @return the direction the Human wants to move
     */
    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        List<Direction> canMovesList = new ArrayList<>();

        for (Direction direction : theNeighbors.keySet()) {
            if (theNeighbors.get(direction) == Terrain.CROSSWALK 
                    && direction != getDirection().reverse()) {
                return direction;
            } else if (canTravel(theNeighbors.get(direction)) && direction != getDirection().reverse()) {
                canMovesList.add(direction);
            }
        }

        if (canMovesList.isEmpty()) {
            return getDirection().reverse();
        } else {
            return canMovesList.get(random.nextInt(canMovesList.size()));
        }
    }

    /**
     * Determines whether this Human can travel over the specified terrain.
     *
     * @param terrain the terrain to check
     * @return true if the Human can travel over the terrain; false otherwise
     */
    private boolean canTravel(Terrain terrain) {
        return terrain == Terrain.GRASS || terrain == Terrain.CROSSWALK;
    }
}
