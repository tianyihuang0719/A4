package model;

import java.util.Map;

/**
 * Represents a Car that can move in four directions.
 * This class extends the {@link AbstractVehicle} class and implements
 * specific movement rules for the Car, including its ability to traverse
 * different types of terrain and the conditions under which it can pass
 * through certain terrains.
 *
 * @author TCSS 305 instructors
 * @version 1.0
 */
public class Car extends AbstractVehicle {
    private static final int DEATH_TIME = 10;

    /**
     * Constructs a new Car with the specified initial position and direction.
     *
     * @param x the initial x-coordinate of the Car
     * @param y the initial y-coordinate of the Car
     * @param direction the initial direction the Car is facing
     */
    public Car(int x, int y, Direction direction) {
        super(x, y, direction, DEATH_TIME);
    }

    /**
     * Determines whether this Car can pass over the specified terrain,
     * considering the light color.
     *
     * @param theTerrain the terrain to check
     * @param theLight the color of the street light
     * @return true if the Car can pass; false otherwise
     */
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if (theTerrain == Terrain.STREET) {
            return true;
        } else if (theTerrain == Terrain.LIGHT || theTerrain == Terrain.CROSSWALK) {
            if (theLight == Light.GREEN) {
                return true;
            }
        }
        return false;
    }

    /**
     * Chooses the direction this Car would like to move, based on the
     * neighboring terrain provided in a map.
     *
     * @param theNeighbors a map of neighboring terrain
     * @return the direction the Car wants to move
     */
    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        if (canTravel(theNeighbors.get(getDirection()))) {
            return getDirection();
        } else if (canTravel(theNeighbors.get(getDirection().left()))) {
            return getDirection().left();
        } else if (canTravel(theNeighbors.get(getDirection().right()))) {
            return getDirection().right();
        } else {
            return getDirection().reverse();
        }
    }

    /**
     * Determines whether this Car can travel over the specified terrain.
     *
     * @param terrain the terrain to check
     * @return true if the Car can travel over the terrain; false otherwise
     */
    private boolean canTravel(Terrain terrain) {
        return terrain == Terrain.STREET || terrain == Terrain.LIGHT || terrain == Terrain.CROSSWALK;
    }
}
