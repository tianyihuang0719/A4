package tests;

import model.Direction;
import model.Light;
import model.Terrain;
import model.Truck;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Unit tests for class Truck.
 *
 * @author TCSS 305 instructors
 * @version 1.0
 */
public class TruckTest {

    /** Test method for Truck constructor. */
    @Test
    public void testTruckConstructor() {
        final Truck truck = new Truck(5, 5, Direction.NORTH);

        assertEquals("Truck x coordinate not initialized correctly!", 5, truck.getX());
        assertEquals("Truck y coordinate not initialized correctly!", 5, truck.getY());
        assertEquals("Truck direction not initialized correctly!", Direction.NORTH, truck.getDirection());
        assertEquals("Truck death time not initialized correctly!", 0, truck.getDeathTime());
        assertTrue("Truck should be alive initially!", truck.isAlive());
    }

    /** Test method for Truck#canPass() for different terrain and light conditions. */
    @Test
    public void testCanPass() {
        final Truck truck = new Truck(0, 0, Direction.NORTH);

        // Test passable terrains
        assertTrue("Truck should be able to pass STREET", truck.canPass(Terrain.STREET, Light.GREEN));
        assertTrue("Truck should be able to pass LIGHT", truck.canPass(Terrain.LIGHT, Light.RED));
        assertTrue("Truck should be able to pass CROSSWALK under YELLOW light", truck.canPass(Terrain.CROSSWALK, Light.YELLOW));

        // Test non-passable terrains
        assertFalse("Truck should NOT be able to pass CROSSWALK under RED light", truck.canPass(Terrain.CROSSWALK, Light.RED));
        assertFalse("Truck should NOT be able to pass GRASS", truck.canPass(Terrain.GRASS, Light.GREEN));
        assertFalse("Truck should NOT be able to pass other terrains", truck.canPass(Terrain.TRAIL, Light.GREEN));
    }

    /** Test method for Truck#chooseDirection() with various neighboring terrains. */
    @Test
    public void testChooseDirection() {
        final Truck truck = new Truck(0, 0, Direction.NORTH);
        Map<Direction, Terrain> neighbors = new HashMap<>();

        // Test with STREET all around
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.SOUTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.STREET);
        neighbors.put(Direction.WEST, Terrain.STREET);

        // Truck can choose any direction
        for (int i = 0; i < 100; i++) {
            Direction chosenDirection = truck.chooseDirection(neighbors);
            assertTrue("Truck should choose STREET direction!",
                    chosenDirection == Direction.NORTH 
                    || chosenDirection == Direction.SOUTH 
                    || chosenDirection == Direction.EAST 
                    || chosenDirection == Direction.WEST);
        }

        // Test with no passable terrains
        neighbors.put(Direction.NORTH, Terrain.GRASS);
        neighbors.put(Direction.SOUTH, Terrain.GRASS);
        neighbors.put(Direction.EAST, Terrain.GRASS);
        neighbors.put(Direction.WEST, Terrain.GRASS);

        // Truck should reverse direction since no options are available
        Direction chosenDirection = truck.chooseDirection(neighbors);
        assertEquals("Truck should reverse direction when no valid moves exist", Direction.NORTH.reverse(), chosenDirection);
    }

    /** Test method for Truck collision behavior. */
    @Test
    public void testCollide() {
        final Truck truck1 = new Truck(0, 0, Direction.NORTH);
        final Truck truck2 = new Truck(1, 0, Direction.SOUTH);

        // Both trucks should be alive initially
        assertTrue(truck1.isAlive());
        assertTrue(truck2.isAlive());

        // Test collision logic
        truck1.collide(truck2);
        assertFalse("Truck1 should be dead after colliding with Truck2!", truck1.isAlive());

        // Test that truck2 remains alive
        assertTrue("Truck2 should still be alive!", truck2.isAlive());
    }

    /** Test method for Truck reset functionality. */
    @Test
    public void testReset() {
        final Truck truck = new Truck(5, 5, Direction.NORTH);
        truck.setX(10);
        truck.setY(10);
        truck.setDirection(Direction.EAST);
        truck.collide(new Truck(1, 1, Direction.SOUTH)); // Simulate death
        assertFalse("Truck should be dead after collision!", truck.isAlive());

        truck.reset();
        assertEquals("Truck x coordinate should be reset!", 5, truck.getX());
        assertEquals("Truck y coordinate should be reset!", 5, truck.getY());
        assertEquals("Truck direction should be reset!", Direction.NORTH, truck.getDirection());
        assertTrue("Truck should be alive after reset!", truck.isAlive());
    }
}
