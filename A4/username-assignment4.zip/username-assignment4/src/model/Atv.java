package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Represents an All-Terrain Vehicle (ATV) that can move in four directions.
 * This class extends the {@link AbstractVehicle} class and implements
 * specific movement rules for the ATV, including its ability to traverse
 * different types of terrain.
 *
 * @author TCSS 305 instructors
 * @version 1.0
 */
public class Atv extends AbstractVehicle {
    private static final int DEATH_TIME = 20;

    /**
     * Constructs a new ATV with the specified initial position and direction.
     *
     * @param x the initial x-coordinate of the ATV
     * @param y the initial y-coordinate of the ATV
     * @param direction the initial direction the ATV is facing
     */
    public Atv(int x, int y, Direction direction) {
        super(x, y, direction, DEATH_TIME);
    }

    /**
     * Determines whether this ATV can pass over the specified terrain,
     * considering the light color.
     *
     * @param theTerrain the terrain to check
     * @param theLight the color of the street light (not used in this implementation)
     * @return true if the ATV can pass; false otherwise
     */
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        return canTravel(theTerrain);
    }

    /**
     * Chooses the direction this ATV would like to move, based on the
     * neighboring terrain provided in a map.
     *
     * @param theNeighbors a map of neighboring terrain
     * @return the direction the ATV wants to move
     */
    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        List<Direction> canMovesList = new ArrayList<>();

        if (canTravel(theNeighbors.get(getDirection()))) {
            canMovesList.add(getDirection());
        }

        if (canTravel(theNeighbors.get(getDirection().left()))) {
            canMovesList.add(getDirection().left());
        }

        if (canTravel(theNeighbors.get(getDirection().right()))) {
            canMovesList.add(getDirection().right());
        }

        if (canMovesList.isEmpty()) {
            return getDirection().reverse();
        } else {
            return canMovesList.get(random.nextInt(canMovesList.size()));
        }
    }

    /**
     * Determines whether this ATV can travel over the specified terrain.
     *
     * @param terrain the terrain to check
     * @return true if the ATV can travel over the terrain; false otherwise
     */
    private boolean canTravel(Terrain terrain) {
        return terrain != Terrain.WALL;
    }
}
