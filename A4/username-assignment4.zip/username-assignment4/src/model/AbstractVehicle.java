package model;

import java.util.Map;
import java.util.Random;

/**
 * An abstract class that represents a vehicle that can move in four directions.
 * This class implements the {@link Vehicle} interface and provides basic functionality
 * for managing the vehicle's state, including its position, direction, and whether
 * it is alive or dead.
 *
 * @author TCSS 305 instructors
 * @version 1.2
 */
public abstract class AbstractVehicle implements Vehicle {
    protected static final Random random = new Random(System.currentTimeMillis());

    private final int initX;
    private final int initY;
    private final Direction initDirection;
    private final int deathTime;
    private int x;
    private int y;
    private Direction direction;
    private int howLongHasDead;
    private boolean alive;

    /**
     * Constructs a new vehicle with the specified initial position, direction, and death time.
     *
     * @param x the initial x-coordinate of the vehicle
     * @param y the initial y-coordinate of the vehicle
     * @param direction the initial direction the vehicle is facing
     * @param deathTime the number of updates before the vehicle can be revived after death
     */
    protected AbstractVehicle(int x, int y, Direction direction, int deathTime) {
        this.initX = x;
        this.initY = y;
        this.initDirection = direction;
        this.deathTime = deathTime;
        reset();
    }

    /**
     * Returns whether or not this object may move onto the given type of
     * terrain, when the street lights are the given color.
     *
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return whether or not this object may move onto the given type of
     *         terrain when the street lights are the given color.
     */
    @Override
    public abstract boolean canPass(Terrain theTerrain, Light theLight);

    /**
     * Returns the direction this object would like to move, based on the given
     * map of the neighboring terrain.
     *
     * @param theNeighbors The map of neighboring terrain.
     * @return the direction this object would like to move.
     */
    @Override
    public abstract Direction chooseDirection(Map<Direction, Terrain> theNeighbors);

    /**
     * Called when this Vehicle collides with the specified other Vehicle.
     *
     * @param theOther The other object.
     */
    @Override
    public void collide(Vehicle theOther) {
        if (alive && theOther.isAlive() && this.deathTime >= theOther.getDeathTime()) {
            this.alive = false;
        }
    }

    /**
     * Returns the number of updates between this vehicle's death and when it
     * should be revived.
     *
     * @return the number of updates.
     */
    @Override
    public int getDeathTime() {
        return deathTime;
    }

    /**
     * Returns the file name of the image for this Vehicle object, such as
     * "car.gif".
     *
     * @return the file name.
     */
    @Override
    public String getImageFileName() {
        String name = getClass().getSimpleName().toLowerCase();
        if (alive) {
            return name + ".gif";
        }
        return name + "_dead.gif";
    }

    /**
     * Returns this Vehicle object's direction.
     *
     * @return the direction.
     */
    @Override
    public Direction getDirection() {
        return direction;
    }

    /**
     * Returns this Vehicle object's x-coordinate.
     *
     * @return the x-coordinate.
     */
    @Override
    public int getX() {
        return x;
    }

    /**
     * Returns this Vehicle object's y-coordinate.
     *
     * @return the y-coordinate.
     */
    @Override
    public int getY() {
        return y;
    }

    /**
     * Returns whether this Vehicle object is alive and should move on the map.
     *
     * @return true if the object is alive, false otherwise.
     */
    @Override
    public boolean isAlive() {
        return alive;
    }

    /**
     * Called by the UI to notify a dead vehicle that 1 movement round has
     * passed, so that it will become 1 move closer to revival.
     */
    @Override
    public void poke() {
        if (!alive) {
            howLongHasDead++;
            if (howLongHasDead >= getDeathTime()) {
                alive = true;
                howLongHasDead = 0;
                direction = Direction.randomDirection();
            }
        }
    }

    /**
     * Moves this vehicle back to its original position.
     */
    @Override
    public void reset() {
        this.x = initX;
        this.y = initY;
        this.direction = initDirection;
        this.howLongHasDead = 0;
        this.alive = true;
    }

    /**
     * Sets this object's facing direction to the given value.
     *
     * @param direction The new direction.
     */
    @Override
    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    /**
     * Sets this object's x-coordinate to the given value.
     *
     * @param x The new x-coordinate.
     */
    @Override
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Sets this object's y-coordinate to the given value.
     *
     * @param y The new y-coordinate.
     */
    @Override
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Returns a string representation of this vehicle, including its type,
     * position, direction, and alive status.
     *
     * @return a string containing vehicle details
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Type: " + getClass().getSimpleName()).append(System.lineSeparator());
        sb.append(String.format("Position: %d, %d", x, y)).append(System.lineSeparator());
        sb.append(String.format("Direction: %s", direction.letter())).append(System.lineSeparator());
        sb.append(String.format("Alive: %b", alive)).append(System.lineSeparator());
        if (!alive) {
            sb.append(String.format("How long has been dead: %d", howLongHasDead)).append(System.lineSeparator());
        }
        return sb.toString();
    }
}
